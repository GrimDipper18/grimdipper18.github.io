/* ==========================================================================
   PlayHub — Homepage logic
   Lightweight, dependency-free. Tuned for Chromebooks / low-power devices.
   ========================================================================== */

const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];

/* ---------- Theme ---------- */
const THEME_KEY = 'ph_theme';
function applyTheme(t) {
  document.documentElement.setAttribute('data-theme', t);
  const btn = $('#themeBtn');
  if (btn) btn.textContent = t === 'dark' ? '🌙' : '☀️';
  const meta = document.querySelector('meta[name="theme-color"]');
  if (meta) meta.setAttribute('content', t === 'dark' ? '#0b1020' : '#f4f6fc');
}
function initTheme() {
  let t = 'dark';
  try { t = localStorage.getItem(THEME_KEY) || 'dark'; } catch {}
  applyTheme(t);
  $('#themeBtn')?.addEventListener('click', () => {
    const next = document.documentElement.getAttribute('data-theme') === 'dark' ? 'light' : 'dark';
    applyTheme(next);
    try { localStorage.setItem(THEME_KEY, next); } catch {}
  });
}

/* ---------- Navigation helpers ---------- */
function normalize(input) {
  let u = (input || '').trim();
  if (!u) return '';
  if (/^https?:\/\//i.test(u)) return u;
  if (/^[\w-]+(\.[\w-]+)+(\/.*)?$/.test(u)) return 'https://' + u;
  return 'https://duckduckgo.com/?q=' + encodeURIComponent(u);
}
function openInBrowser(url) {
  window.location.href = '/app.html?url=' + encodeURIComponent(url);
}

/* ---------- Quick launch ---------- */
const QUICK = [
  { name: 'YouTube',   host: 'youtube.com',        url: 'https://www.youtube.com',        ico: '▶️', bg: 'linear-gradient(135deg,#ef4444,#7f1d1d)' },
  { name: 'Wikipedia', host: 'wikipedia.org',      url: 'https://en.wikipedia.org',       ico: '📚', bg: 'linear-gradient(135deg,#64748b,#1e293b)' },
  { name: 'GitHub',    host: 'github.com',         url: 'https://github.com',             ico: '🐙', bg: 'linear-gradient(135deg,#334155,#0f172a)' },
  { name: 'Reddit',    host: 'reddit.com',         url: 'https://www.reddit.com',         ico: '👽', bg: 'linear-gradient(135deg,#f97316,#7c2d12)' },
  { name: 'Twitch',    host: 'twitch.tv',          url: 'https://www.twitch.tv',          ico: '🎥', bg: 'linear-gradient(135deg,#a855f7,#4c1d95)' },
  { name: 'Steam',     host: 'steampowered.com',   url: 'https://store.steampowered.com', ico: '🕹️', bg: 'linear-gradient(135deg,#0ea5e9,#0c4a6e)' },
  { name: 'Xbox',      host: 'xbox.com',           url: 'https://www.xbox.com/en-US/play',ico: '🎮', bg: 'linear-gradient(135deg,#22c55e,#14532d)' },
  { name: 'Spotify',   host: 'spotify.com',        url: 'https://open.spotify.com',       ico: '🎵', bg: 'linear-gradient(135deg,#1db954,#14532d)' },
  { name: 'BBC News',  host: 'bbc.com',            url: 'https://www.bbc.com/news',       ico: '📰', bg: 'linear-gradient(135deg,#b91c1c,#450a0a)' },
  { name: 'Amazon',    host: 'amazon.com',         url: 'https://www.amazon.com',         ico: '📦', bg: 'linear-gradient(135deg,#f59e0b,#78350f)' },
  { name: 'Gmail',     host: 'mail.google.com',    url: 'https://mail.google.com',        ico: '✉️', bg: 'linear-gradient(135deg,#ea4335,#7f1d1d)' },
  { name: 'Maps',      host: 'maps.google.com',    url: 'https://maps.google.com',        ico: '🗺️', bg: 'linear-gradient(135deg,#10b981,#064e3b)' },
];

function renderQuick() {
  const grid = $('#quickGrid');
  if (!grid) return;
  const frag = document.createDocumentFragment();
  QUICK.forEach((q) => {
    const el = document.createElement('button');
    el.className = 'tile';
    el.type = 'button';
    el.innerHTML = `<span class="t-ico">${q.ico}</span><span class="t-name">${q.name}</span><span class="t-host">${q.host}</span>`;
    el.addEventListener('click', () => openInBrowser(q.url));
    frag.appendChild(el);
  });
  grid.appendChild(frag);
}

/* ---------- Games ---------- */
const GAMES = [
  { name: 'Snake',        desc: 'Classic arcade snake. Eat, grow, don’t crash.', ico: '🐍', tag: 'Arcade',   href: 'games/snake.html',    bg: 'linear-gradient(135deg,#22c55e,#065f46)' },
  { name: 'Breakout',     desc: 'Smash every brick with the bouncing ball.',      ico: '🧱', tag: 'Arcade',   href: 'games/breakout.html', bg: 'linear-gradient(135deg,#3b82f6,#1e3a8a)' },
  { name: '2048',         desc: 'Slide tiles and merge numbers to reach 2048.',   ico: '🔢', tag: 'Puzzle',   href: 'games/2048.html',     bg: 'linear-gradient(135deg,#f59e0b,#b45309)' },
  { name: 'Memory Match', desc: 'Flip cards and find every matching pair.',       ico: '🃏', tag: 'Puzzle',   href: 'games/memory.html',   bg: 'linear-gradient(135deg,#a855f7,#6b21a8)' },
  { name: 'Pong',         desc: 'Retro paddle duel against the computer.',        ico: '🏓', tag: 'Retro',    href: 'games/pong.html',     bg: 'linear-gradient(135deg,#ef4444,#7f1d1d)' },
  { name: 'Tetris',       desc: 'Stack falling blocks and clear the lines.',      ico: '🧩', tag: 'Puzzle',   href: 'games/tetris.html',   bg: 'linear-gradient(135deg,#06b6d4,#155e75)' },
];

function renderGames() {
  const grid = $('#gameGrid');
  if (!grid) return;
  const frag = document.createDocumentFragment();
  GAMES.forEach((g) => {
    const a = document.createElement('a');
    a.className = 'game reveal';
    a.href = g.href;
    a.innerHTML = `
      <span class="g-tag">${g.tag}</span>
      <div class="g-thumb" style="background:${g.bg}">${g.ico}</div>
      <div class="g-body"><h3>${g.name}</h3><p>${g.desc}</p></div>`;
    frag.appendChild(a);
  });
  grid.appendChild(frag);
}

/* ---------- Live stats ---------- */
function fmtUptime(s) {
  if (s < 60) return s + 's';
  if (s < 3600) return Math.floor(s / 60) + 'm';
  if (s < 86400) return Math.floor(s / 3600) + 'h';
  return Math.floor(s / 86400) + 'd';
}
async function loadStats() {
  try {
    const r = await fetch('/api/stats', { cache: 'no-store' });
    if (!r.ok) return;
    const s = await r.json();
    const set = (id, v) => { const el = $(id); if (el) el.textContent = v; };
    set('#statReq', (s.requests || 0).toLocaleString());
    set('#statCache', (s.cacheHits || 0).toLocaleString());
    set('#statUp', fmtUptime(s.uptimeSec || 0));
  } catch {}
}

/* ---------- Reveal on scroll (IntersectionObserver, cheap) ---------- */
function initReveal() {
  const els = $$('.reveal');
  if (!('IntersectionObserver' in window)) { els.forEach((e) => e.classList.add('in')); return; }
  const io = new IntersectionObserver((entries) => {
    entries.forEach((en) => { if (en.isIntersecting) { en.target.classList.add('in'); io.unobserve(en.target); } });
  }, { rootMargin: '0px 0px -8% 0px', threshold: 0.05 });
  els.forEach((e) => io.observe(e));
}

/* ---------- Wire up ---------- */
function init() {
  initTheme();
  renderQuick();
  renderGames();
  loadStats();
  setInterval(loadStats, 15000);
  initReveal();

  // Omnibar
  $('#omniForm')?.addEventListener('submit', (e) => {
    e.preventDefault();
    const url = normalize($('#omniInput').value);
    if (url) openInBrowser(url);
  });

  // Chips
  $$('#chips .chip').forEach((c) => c.addEventListener('click', () => openInBrowser(c.dataset.url)));

  // Mobile drawer
  $('#menuBtn')?.addEventListener('click', () => $('#drawer')?.classList.toggle('open'));
  $$('#drawer a').forEach((a) => a.addEventListener('click', () => $('#drawer')?.classList.remove('open')));

  // Keyboard: "/" focuses the omnibar
  document.addEventListener('keydown', (e) => {
    if (e.key === '/' && document.activeElement !== $('#omniInput')) {
      e.preventDefault();
      $('#omniInput')?.focus();
    }
  });
}

if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
else init();
