/* ==========================================================================
   PlayHub v3 — app shell logic
   Multi-tab browsing, bookmarks, history, settings, command palette, AI.
   ========================================================================== */

const $ = (id) => document.getElementById(id);

// --- Persistent state -------------------------------------------------------
const store = {
  get(k, d) { try { return JSON.parse(localStorage.getItem('ph_' + k)) ?? d; } catch { return d; } },
  set(k, v) { localStorage.setItem('ph_' + k, JSON.stringify(v)); },
};

const settings = {
  theme: store.get('theme', 'dark'),
  home: store.get('home', 'https://example.com'),
  search: store.get('search', 'https://duckduckgo.com/?q='),
  aiKey: store.get('aiKey', ''),
  aiBase: store.get('aiBase', 'https://api.openai.com/v1'),
  aiModel: store.get('aiModel', 'gpt-4o-mini'),
};

let bookmarks = store.get('bookmarks', []);
let history = store.get('history', []);

// --- Tabs -------------------------------------------------------------------
let tabs = [];
let activeTab = 0;
let tabSeq = 0;

function newTab(url = '') {
  const tab = { id: ++tabSeq, url: url || '', title: url ? 'Loading…' : 'New Tab', history: [], hIndex: -1 };
  tabs.push(tab);
  activeTab = tabs.length - 1;
  renderTabs();
  if (url) navigate(url);
  else { $('frame').src = 'about:blank'; $('omniInput').value = ''; setStatus('New tab'); }
}

function closeTab(idx) {
  if (tabs.length === 1) { newTab(); tabs.splice(0, 1); activeTab = 0; }
  else { tabs.splice(idx, 1); if (activeTab >= tabs.length) activeTab = tabs.length - 1; }
  renderTabs();
  const t = tabs[activeTab];
  if (t && t.url) { $('omniInput').value = t.url; $('frame').src = proxyUrl(t.url); }
  else { $('frame').src = 'about:blank'; }
}

function renderTabs() {
  const strip = $('tabstrip');
  strip.innerHTML = '';
  tabs.forEach((t, i) => {
    const el = document.createElement('div');
    el.className = 'tab' + (i === activeTab ? ' active' : '');
    el.innerHTML = `<span class="tab-title">${escapeHtml(t.title || 'New Tab')}</span><span class="tab-close">✕</span>`;
    el.addEventListener('click', (e) => {
      if (e.target.classList.contains('tab-close')) { closeTab(i); return; }
      activeTab = i;
      renderTabs();
      if (t.url) { $('omniInput').value = t.url; $('frame').src = proxyUrl(t.url); }
      else { $('frame').src = 'about:blank'; }
    });
    strip.appendChild(el);
  });
}

// --- Navigation -------------------------------------------------------------
function normalize(input) {
  let u = (input || '').trim();
  if (!u) return '';
  if (/^https?:\/\//i.test(u)) return u;
  // Looks like a domain?
  if (/^[\w-]+(\.[\w-]+)+(\/.*)?$/.test(u)) return 'https://' + u;
  // Otherwise search
  return settings.search + encodeURIComponent(u);
}
function proxyUrl(target) { return '/proxy?url=' + encodeURIComponent(target); }

function navigate(input, pushHistory = true) {
  const url = normalize(input);
  if (!url) return;
  const t = tabs[activeTab];
  t.url = url;
  $('omniInput').value = url;
  setStatus('Loading ' + url + ' …');
  $('loading').classList.add('show');
  $('frame').src = proxyUrl(url);
  if (pushHistory) {
    t.history.splice(t.hIndex + 1);
    t.history.push(url);
    t.hIndex = t.history.length - 1;
    addHistory(url);
  }
  updateNav();
  updateStar();
}

function updateNav() {
  const t = tabs[activeTab];
  $('back').disabled = !t || t.hIndex <= 0;
  $('fwd').disabled = !t || t.hIndex >= t.history.length - 1;
}

function setStatus(txt) { $('statusText').textContent = txt; }

// --- History / bookmarks ----------------------------------------------------
function addHistory(url) {
  history.unshift({ url, time: Date.now() });
  history = history.slice(0, 300);
  store.set('history', history);
}
function renderHistory() {
  const list = $('historyList');
  list.innerHTML = '';
  if (!history.length) { list.innerHTML = '<div class="empty">No history yet.</div>'; return; }
  history.forEach((h, i) => {
    const el = document.createElement('div');
    el.className = 'list-item';
    el.innerHTML = `<div class="li-main"><div class="li-title">${escapeHtml(h.url)}</div>
      <div class="li-sub">${new Date(h.time).toLocaleString()}</div></div>
      <span class="li-del">✕</span>`;
    el.addEventListener('click', (e) => {
      if (e.target.classList.contains('li-del')) { history.splice(i, 1); store.set('history', history); renderHistory(); return; }
      switchView('browser'); navigate(h.url);
    });
    list.appendChild(el);
  });
}
function renderBookmarks() {
  const list = $('bookmarkList');
  list.innerHTML = '';
  if (!bookmarks.length) { list.innerHTML = '<div class="empty">No bookmarks yet. Click ☆ in the address bar.</div>'; return; }
  bookmarks.forEach((b, i) => {
    const el = document.createElement('div');
    el.className = 'list-item';
    el.innerHTML = `<div class="li-main"><div class="li-title">${escapeHtml(b.title || b.url)}</div>
      <div class="li-sub">${escapeHtml(b.url)}</div></div><span class="li-del">✕</span>`;
    el.addEventListener('click', (e) => {
      if (e.target.classList.contains('li-del')) { bookmarks.splice(i, 1); store.set('bookmarks', bookmarks); renderBookmarks(); return; }
      switchView('browser'); navigate(b.url);
    });
    list.appendChild(el);
  });
}
function updateStar() {
  const t = tabs[activeTab];
  const starred = t && bookmarks.some((b) => b.url === t.url);
  $('starBtn').textContent = starred ? '★' : '☆';
  $('starBtn').style.color = starred ? 'var(--warn)' : '';
}

// --- Views ------------------------------------------------------------------
function switchView(name) {
  document.querySelectorAll('.view').forEach((v) => v.classList.remove('active'));
  $('view-' + name).classList.add('active');
  document.querySelectorAll('.nav-item').forEach((n) => n.classList.toggle('active', n.dataset.view === name));
  if (name === 'history') renderHistory();
  if (name === 'bookmarks') renderBookmarks();
  if (name === 'stats') loadStats();
}

// --- Stats ------------------------------------------------------------------
async function loadStats() {
  try {
    const r = await fetch('/api/stats');
    const s = await r.json();
    const cards = [
      ['Requests', s.requests], ['Cache hits', s.cacheHits], ['Cache misses', s.cacheMisses],
      ['Coalesced', s.coalesced], ['Errors', s.errors], ['Cache entries', s.cacheEntries],
      ['Data out', fmtBytes(s.bytesOut)], ['Uptime', s.uptimeSec + 's'],
    ];
    $('statGrid').innerHTML = cards.map(([l, v]) =>
      `<div class="stat-card"><div class="sv">${v}</div><div class="sl">${l}</div></div>`).join('');
    $('topHosts').innerHTML = (s.topHosts || []).map((h) =>
      `<div class="list-item"><div class="li-main"><div class="li-title">${escapeHtml(h.host)}</div>
       <div class="li-sub">${h.count} requests · avg ${h.avgMs}ms</div></div></div>`).join('')
      || '<div class="empty">No traffic yet.</div>';
  } catch { $('statGrid').innerHTML = '<div class="empty">Stats unavailable.</div>'; }
}

// --- Games ------------------------------------------------------------------
const GAMES = [
  { name: 'Snake', file: 'snake.html', icon: '🐍', desc: 'Classic arcade snake.', grad: 'linear-gradient(135deg,#22c55e,#065f46)' },
  { name: 'Breakout', file: 'breakout.html', icon: '🧱', desc: 'Smash every brick.', grad: 'linear-gradient(135deg,#3b82f6,#1e3a8a)' },
  { name: '2048', file: '2048.html', icon: '🔢', desc: 'Merge tiles to 2048.', grad: 'linear-gradient(135deg,#f59e0b,#b45309)' },
  { name: 'Memory Match', file: 'memory.html', icon: '🃏', desc: 'Find matching pairs.', grad: 'linear-gradient(135deg,#a855f7,#6b21a8)' },
  { name: 'Pong', file: 'pong.html', icon: '🏓', desc: 'Retro paddle duel.', grad: 'linear-gradient(135deg,#ef4444,#7f1d1d)' },
  { name: 'Tetris', file: 'tetris.html', icon: '🧩', desc: 'Stack and clear lines.', grad: 'linear-gradient(135deg,#06b6d4,#155e75)' },
];
function renderGames() {
  $('gameGrid').innerHTML = GAMES.map((g) =>
    `<a class="game-card" href="games/${g.file}" target="_blank">
      <div class="game-thumb" style="background:${g.grad}">${g.icon}</div>
      <div class="game-body"><h3>${g.name}</h3><p>${g.desc}</p></div></a>`).join('');
}

// --- Command palette --------------------------------------------------------
const COMMANDS = [
  { icon: '🌐', label: 'New tab', run: () => newTab() },
  { icon: '🎯', label: 'Open Games', run: () => switchView('games') },
  { icon: '⭐', label: 'Open Bookmarks', run: () => switchView('bookmarks') },
  { icon: '🕘', label: 'Open History', run: () => switchView('history') },
  { icon: '📊', label: 'Open Stats', run: () => switchView('stats') },
  { icon: '⚙️', label: 'Open Settings', run: () => switchView('settings') },
  { icon: '✨', label: 'Toggle AI Assistant', run: () => toggleAI() },
  { icon: '🌓', label: 'Toggle theme', run: () => toggleTheme() },
];
let paletteSel = 0;
function openPalette() { $('paletteOverlay').classList.add('open'); $('paletteInput').value = ''; renderPalette(''); $('paletteInput').focus(); }
function closePalette() { $('paletteOverlay').classList.remove('open'); }
function renderPalette(q) {
  const list = $('paletteList');
  const items = COMMANDS.filter((c) => c.label.toLowerCase().includes(q.toLowerCase()));
  if (q && !items.length) items.push({ icon: '🔎', label: 'Search / go to: ' + q, run: () => { switchView('browser'); navigate(q); } });
  paletteSel = 0;
  list.innerHTML = items.map((c, i) =>
    `<div class="palette-item${i === 0 ? ' sel' : ''}" data-i="${i}"><span class="pi-icon">${c.icon}</span>${escapeHtml(c.label)}</div>`).join('');
  list.querySelectorAll('.palette-item').forEach((el) => {
    el.addEventListener('click', () => { items[+el.dataset.i].run(); closePalette(); });
  });
  list._items = items;
}

// --- AI ---------------------------------------------------------------------
function toggleAI() {
  $('aiPanel').classList.toggle('open');
  $('aiToggle').classList.toggle('active');
}
function addMsg(text, cls) {
  const d = document.createElement('div');
  d.className = 'msg ' + cls; d.textContent = text;
  $('aiLog').appendChild(d); $('aiLog').scrollTop = $('aiLog').scrollHeight;
  return d;
}
function pageText() {
  try {
    const doc = $('frame').contentDocument;
    return doc && doc.body ? doc.body.innerText.replace(/\s+/g, ' ').slice(0, 12000) : '';
  } catch { return ''; }
}
async function ask(messages) {
  if (!settings.aiKey) { addMsg('Add your API key in Settings first.', 'sys'); return; }
  const thinking = addMsg('Thinking…', 'sys');
  try {
    const r = await fetch('/api/assistant', {
      method: 'POST', headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ apiKey: settings.aiKey, baseUrl: settings.aiBase, model: settings.aiModel, messages }),
    });
    const data = await r.json();
    thinking.remove();
    const reply = data.choices?.[0]?.message?.content || (data.error ? 'Error: ' + (data.error.message || data.error) : 'No response.');
    addMsg(reply, 'ai');
  } catch (err) { thinking.remove(); addMsg('Request failed: ' + err.message, 'sys'); }
}

// --- Theme ------------------------------------------------------------------
function applyTheme() {
  document.documentElement.setAttribute('data-theme', settings.theme);
  $('themeBtn').textContent = settings.theme === 'dark' ? '🌙' : '☀️';
}
function toggleTheme() { settings.theme = settings.theme === 'dark' ? 'light' : 'dark'; store.set('theme', settings.theme); applyTheme(); }

// --- Helpers ----------------------------------------------------------------
function escapeHtml(s) { return String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c])); }
function fmtBytes(n) { if (n < 1024) return n + ' B'; if (n < 1048576) return (n / 1024).toFixed(1) + ' KB'; return (n / 1048576).toFixed(1) + ' MB'; }

// --- Wire up ----------------------------------------------------------------
$('omniForm').addEventListener('submit', (e) => { e.preventDefault(); navigate($('omniInput').value); });
$('back').addEventListener('click', () => { const t = tabs[activeTab]; if (t.hIndex > 0) { t.hIndex--; navigate(t.history[t.hIndex], false); } });
$('fwd').addEventListener('click', () => { const t = tabs[activeTab]; if (t.hIndex < t.history.length - 1) { t.hIndex++; navigate(t.history[t.hIndex], false); } });
$('reload').addEventListener('click', () => { const t = tabs[activeTab]; if (t.url) navigate(t.url, false); });
$('home').addEventListener('click', () => navigate(settings.home));
$('newTabBtn').addEventListener('click', () => newTab());
$('starBtn').addEventListener('click', () => {
  const t = tabs[activeTab]; if (!t || !t.url) return;
  const idx = bookmarks.findIndex((b) => b.url === t.url);
  if (idx > -1) bookmarks.splice(idx, 1); else bookmarks.unshift({ url: t.url, title: t.title });
  store.set('bookmarks', bookmarks); updateStar(); renderBookmarks();
});
$('aiToggle').addEventListener('click', toggleAI);
$('aiClose').addEventListener('click', toggleAI);
$('aiSend').addEventListener('click', () => { const q = $('aiMsg').value.trim(); if (!q) return; addMsg(q, 'user'); $('aiMsg').value = ''; ask([{ role: 'user', content: q }]); });
$('aiMsg').addEventListener('keydown', (e) => { if (e.key === 'Enter') $('aiSend').click(); });
$('aiSummarize').addEventListener('click', () => { const t = pageText(); if (!t) { addMsg('Could not read page content.', 'sys'); return; } addMsg('Summarize this page.', 'user'); ask([{ role: 'user', content: 'Summarize this web page:\n\n' + t }]); });
$('aiAskPage').addEventListener('click', () => { const q = prompt('What do you want to know about this page?'); if (!q) return; const t = pageText(); addMsg(q, 'user'); ask([{ role: 'user', content: 'Based on this page:\n\n' + t + '\n\nAnswer: ' + q }]); });

document.querySelectorAll('.nav-item').forEach((n) => n.addEventListener('click', () => switchView(n.dataset.view)));
$('collapseBtn').addEventListener('click', () => $('sidebar').classList.toggle('collapsed'));
$('menuBtn').addEventListener('click', () => $('sidebar').classList.toggle('collapsed'));
$('themeBtn').addEventListener('click', toggleTheme);
$('clearHistory').addEventListener('click', () => { history = []; store.set('history', history); renderHistory(); });

// Settings inputs
$('setTheme').value = settings.theme;
$('setHome').value = settings.home;
$('setSearch').value = settings.search;
$('setAiKey').value = settings.aiKey;
$('setAiBase').value = settings.aiBase;
$('setAiModel').value = settings.aiModel;
$('setTheme').addEventListener('change', (e) => { settings.theme = e.target.value; store.set('theme', settings.theme); applyTheme(); });
$('setHome').addEventListener('input', (e) => { settings.home = e.target.value; store.set('home', settings.home); });
$('setSearch').addEventListener('change', (e) => { settings.search = e.target.value; store.set('search', settings.search); });
$('setAiKey').addEventListener('input', (e) => { settings.aiKey = e.target.value; store.set('aiKey', settings.aiKey); });
$('setAiBase').addEventListener('input', (e) => { settings.aiBase = e.target.value; store.set('aiBase', settings.aiBase); });
$('setAiModel').addEventListener('input', (e) => { settings.aiModel = e.target.value; store.set('aiModel', settings.aiModel); });

// Frame load
$('frame').addEventListener('load', () => {
  $('loading').classList.remove('show');
  const t = tabs[activeTab];
  if (t) { setStatus('Loaded: ' + t.url); }
});

// Messages from proxied pages
window.addEventListener('message', (e) => {
  if (e.data && e.data.type === 'ph-navigate' && e.data.url) {
    const t = tabs[activeTab];
    const url = e.data.url;
    t.url = url; $('omniInput').value = url;
    t.history.splice(t.hIndex + 1); t.history.push(url); t.hIndex = t.history.length - 1;
    addHistory(url); updateNav(); updateStar();
    setStatus('Loading ' + url + ' …');
  }
});

// Keyboard shortcuts
document.addEventListener('keydown', (e) => {
  if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k') { e.preventDefault(); openPalette(); }
  if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 't') { e.preventDefault(); newTab(); }
  if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'l') { e.preventDefault(); $('omniInput').focus(); $('omniInput').select(); }
  if (e.key === 'Escape') closePalette();
});
$('paletteOverlay').addEventListener('click', (e) => { if (e.target === $('paletteOverlay')) closePalette(); });
$('paletteInput').addEventListener('input', (e) => renderPalette(e.target.value));
$('paletteInput').addEventListener('keydown', (e) => {
  const items = $('paletteList')._items || [];
  if (e.key === 'ArrowDown') { paletteSel = Math.min(paletteSel + 1, items.length - 1); highlight(); }
  if (e.key === 'ArrowUp') { paletteSel = Math.max(paletteSel - 1, 0); highlight(); }
  if (e.key === 'Enter' && items[paletteSel]) { items[paletteSel].run(); closePalette(); }
});
function highlight() {
  document.querySelectorAll('.palette-item').forEach((el, i) => el.classList.toggle('sel', i === paletteSel));
}

// --- Init -------------------------------------------------------------------
applyTheme();
renderGames();
renderTabs();
// Honor ?url= so links into PlayHub open the requested site directly.
const bootUrl = new URLSearchParams(location.search).get('url');
newTab(bootUrl || settings.home);
