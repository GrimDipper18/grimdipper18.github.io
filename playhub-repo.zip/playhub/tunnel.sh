#!/bin/bash
# Persistent Cloudflare quick-tunnel wrapper.
# Runs cloudflared, captures the public URL, and writes it to PUBLIC_URL.txt
# so the current link is always discoverable even after restarts.
set -u

URLFILE="/workspace/PUBLIC_URL.txt"
LOGFILE="/workspace/tunnel.log"

echo "Starting PlayHub tunnel..." > "$LOGFILE"

while true; do
  # Start cloudflared, tee output so we can parse the URL
  cloudflared tunnel --url http://localhost:3000 --no-autoupdate 2>&1 | while IFS= read -r line; do
    echo "$line" >> "$LOGFILE"
    url=$(echo "$line" | grep -oE 'https://[a-z0-9-]+\.trycloudflare\.com' | head -1)
    if [ -n "$url" ]; then
      echo "$url" > "$URLFILE"
      echo "[$(date -u +%FT%TZ)] Public URL: $url" >> "$LOGFILE"
    fi
  done

  echo "[$(date -u +%FT%TZ)] cloudflared exited; restarting in 3s..." >> "$LOGFILE"
  sleep 3
done
