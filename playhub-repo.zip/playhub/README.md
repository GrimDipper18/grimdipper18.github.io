# PlayHub

PlayHub is a small Node/Express app that combines:

- **A general-purpose HTTP(S) proxy** (`/proxy?url=...`) that fetches a target page, rewrites its HTML/CSS so all links, assets, and forms route back through the proxy, and serves it back to the browser.
- **A tabbed "browser" front end** (`app.html`) with bookmarks, history, and an optional AI assistant sidebar that relays chat requests to an OpenAI-compatible API.
- **A small arcade of instant-play HTML5 games** (2048, Breakout, Memory, Pong, Snake, Tetris) served from `public/games/`.
- **A marketing/landing page** (`index.html`) that showcases the above.

## Architecture

`server.js` is a single-file Express server with:

- **Connection pooling** via an `undici` `Agent` (keep-alive, pipelining).
- **LRU response cache** with stale-while-revalidate (serves a stale copy instantly while refreshing in the background).
- **Request coalescing** — identical in-flight GET requests share one upstream fetch.
- **Per-session token-bucket rate limiting.**
- **Per-host circuit breaker** (stops hammering a host that's failing).
- **Retry with exponential backoff** on upstream fetch failures.
- **User-agent rotation** and a per-session cookie jar for proxied requests.
- **HTML/CSS rewriting** — absolute-izes and proxies every `href`/`src`/`action`/`srcset`/`url()`, strips SRI/CORS headers that would otherwise break rewritten assets, and injects a small script so client-side routers see the real path.
- **MIME sniffing** so mislabeled upstream assets don't get blocked by the browser's ORB checks.
- **WebSocket passthrough** at `/ws?url=wss://...` for real-time sites.
- **`/api/stats` and `/health`** endpoints for basic metrics/uptime.
- **`/api/assistant`** — a thin relay that forwards `{ apiKey, baseUrl, model, messages }` to an OpenAI-compatible chat completions endpoint. The API key is supplied by the client per-request and is never stored server-side.

## Project layout

```
playhub/
├── server.js           # Express server (proxy engine, WS passthrough, assistant relay)
├── package.json
├── package-lock.json
├── tunnel.sh            # optional: run behind a Cloudflare quick tunnel
└── public/
    ├── index.html        # landing page
    ├── home.js / home.css
    ├── app.html           # tabbed browser UI
    ├── app.js / app.css
    ├── browse.html
    ├── style.css
    └── games/
        ├── 2048.html
        ├── breakout.html
        ├── memory.html
        ├── pong.html
        ├── snake.html
        └── tetris.html
```

## Requirements

- Node.js 18+ (uses `undici`, native `fetch`-adjacent APIs, and ES2020+ syntax)

## Setup

```bash
git clone <your-repo-url>
cd playhub
npm install
npm start   # or: node server.js
```

The server listens on `PORT` (defaults to `3000`). Visit `http://localhost:3000`.

### Environment variables

| Variable    | Default | Description                          |
|-------------|---------|---------------------------------------|
| `PORT`      | `3000`  | HTTP port to listen on               |
| `LOG_LEVEL` | `info`  | `debug` \| `info` \| `warn` \| `error` |

### `npm` scripts

Add a start script if you want `npm start` to work (the original `package.json` only defines a placeholder `test` script):

```json
"scripts": {
  "start": "node server.js"
}
```

## Exposing it publicly

`tunnel.sh` runs [`cloudflared`](https://github.com/cloudflare/cloudflared) in a loop, restarting it if it dies, and writes the current public quick-tunnel URL to `PUBLIC_URL.txt`:

```bash
chmod +x tunnel.sh
./tunnel.sh
```

Any tunnel/reverse-proxy tool works equally well (ngrok, a real domain behind Caddy/Nginx, etc.) — `tunnel.sh` is just one option that requires no account/config.

If you deploy the front end (`public/`) separately from the backend (e.g., static hosting + a backend elsewhere), `app.js`/`home.js` support a `?api=https://your-backend` query param (saved to `localStorage`) so the static pages know where to send proxy/API requests. `server.js` itself always serves `public/` directly when run as a normal full-stack app, so this is only needed if you split the deployment.

## Notes

- The AI assistant relay (`/api/assistant`) requires the client to supply their own API key; nothing is persisted server-side.
- The proxy fetches arbitrary user-supplied URLs — if you deploy this publicly, put it behind whatever access control, rate limiting, and logging fits your use case.
- Cached response bodies are capped at 8 MB and the whole cache is capped at 512 MB (see `CACHE_TTL`, `CACHE_STALE`, and the `LRUCache` config in `server.js`).

## License

Add a license of your choice (e.g., MIT) before publishing if you want to state usage terms explicitly.
